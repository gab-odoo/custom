# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.


{
    'name': 'Migration example x_date to gn_date',
    'version': '1.3',
    'category': 'Migration',
    'website': 'https://www.odoo.com/',
    'description': """
This is to demonstrate migration features
""",
    'depends': ['base','product'],
    'data': [

    ],
    'installable': True,
    'auto_install': False,
}